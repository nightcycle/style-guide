local REQUIRED_MODULE = require(script.Parent._Index["nightcycle_cold-fusion@8.0.0"]["cold-fusion"])
export type State<T> = REQUIRED_MODULE.State<T>
export type ValueState<T> = REQUIRED_MODULE.ValueState<T>
export type CanBeState<T> = REQUIRED_MODULE.CanBeState<T>
export type Fuse = REQUIRED_MODULE.Fuse 
return REQUIRED_MODULE
