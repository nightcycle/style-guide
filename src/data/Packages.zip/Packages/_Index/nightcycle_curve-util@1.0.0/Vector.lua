local REQUIRED_MODULE = require(script.Parent.Parent["nightcycle_vector@1.0.2"]["vector"])
export type Vector = REQUIRED_MODULE.Vector 
return REQUIRED_MODULE
