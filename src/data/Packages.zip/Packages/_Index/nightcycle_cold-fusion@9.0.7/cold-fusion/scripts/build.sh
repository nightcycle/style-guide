#!/usr/bin/env bash
source .env/Scripts/Activate
py scripts/build.py