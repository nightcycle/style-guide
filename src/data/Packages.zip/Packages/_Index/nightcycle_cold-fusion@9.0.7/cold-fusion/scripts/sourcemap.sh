#!/usr/bin/env bash
rojo sourcemap dev.project.json --output sourcemap.json