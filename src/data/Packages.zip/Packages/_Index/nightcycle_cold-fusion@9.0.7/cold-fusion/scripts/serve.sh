#!/usr/bin/env bash
rojo serve dev.project.json