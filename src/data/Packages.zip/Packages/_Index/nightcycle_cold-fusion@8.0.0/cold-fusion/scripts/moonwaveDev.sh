#!/bin/bash
npx moonwave dev