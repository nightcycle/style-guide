#!/bin/bash
rojo serve test.project.json